# S2 Ep2 (manhwa ch.7 "Floor Four") — first-frame pack (v3)

All frames: 800x1422 JPEG q85, cropped from `img/ch7/` strips (720 px wide) by crop/panel
choice ONLY — no painting, blur or inpainting. Every file was visually verified free of
speech bubbles, text boxes, lettering, SFX glyphs and watermarks.
Coordinates below are source-strip pixels (x, y, w×h) before the 800x1422 resize.

Merged clips: [1,2,3] [4,5,6] [7,8,9] [10,11,12] [13,14,15] [16,17,18] [19,20]
[21,22,23] [24,25] [26,27] [28,29,30] — frames exist for the 22 boundary beats only.

| Beat | Source | Crop | What the frame shows | Notes |
|---|---|---|---|---|
| 01 | s-001 weapons art | (0,2500,300×533) | The crafted bow's limb and string glowing in blue craft light | **SUBSTITUTION.** The beat's literal panel (Han at the crafting puzzle, top of s-001) is saturated with Korean SFX glyphs over his face and hands — no clean 9:16 window exists in it. Used the bow section of the same craft sequence's weapons art (no glyphs in this window). |
| 03 | s-001 weapons art | (285,2450,380×676) | Spearhead and the hard iron shield in blue craft light — the finished C-rank row | Same weapons art panel as beat 1, different region (the art runs under the "COMPLETE SUCCESS" boxes; this window sits below/right of them, glyph-free). |
| 04 | s-001 panel 2 | (0,4280,285×507) | Han stretching after the crafts, mouth open mid-refusal, eyes half-closed | Literal panel for beats 3–4 dialogue; cropped left of the black narration box and above the lower bubbles. |
| 06 | s-002 Floor-4 party panel | (114,7480,253×450) | Han's hard, determined face during the gate briefing | Threaded crop: the panel's speech bubbles fence Han's face above and below; this is the only clean window. Ch.7 has no separate Iselle briefing panel — the banner + party panel is the briefing moment. |
| 07 | s-002 harpy splash | (40,8930,365×649) | The harpy queen's upper body, wings spread, second harpy at lower left | Literal splash panel; both speech bubbles cropped out (top and right). |
| 09 | s-003 | (0,2185,329×585) | Aaron screaming, swinging his spear in a panic | Bubble tail excluded top-right, purple SFX glyphs excluded at the bottom. |
| 10 | s-003 slap panel | (0,7080,324×576) | Jenna mid-slap, fierce close-up, freckles and amber eyes | Literal panel; the red SFX column at the panel's right edge is excluded. |
| 12 | s-004 battle splash | (0,60,720×1280) | Full battle: Aaron's spear thrust centre, Jenna loosing an arrow at the harpy above, Han's shield at the bottom | Literal panel — the chapter's only completely text-free splash; full-width crop. |
| 13 | s-004 aftermath panel | (0,6575,400×711) | Han in profile after the fight, shield on his arm, feathers drifting | **SUBSTITUTION.** The manhwa renders "STAGE CLEAR" only as text/reward boxes — there is no wide aftermath panel. This is the post-battle panel from the same scene. |
| 15 | s-004 full-bleed panel | (90,11240,540×960) | Aaron screaming "I MADE IT" — face and blood-spattered shirt fill the frame | Literal panel, completely clean in the source. |
| 16 | s-005 panel 1 | (55,316,303×539) | Jenna beaming (the "subordinate number two" joke) | **FLAG:** the only bubble-free band of the panel is ~303 px wide → soft upscale to 800. Han's hair sliver at top-right is panel art. |
| 18 | s-005 terrace panel | (315,11860,405×711) | Sirris Argent from behind: blonde bun, silver pauldrons, white cape against the dusk sky | **FLAG:** ch.7 contains NO front-face Sirris panel (her only other appearance is a shadowed silhouette card with baked-in name lettering). The back view is the chapter's actual reveal framing for her. |
| 19 | s-006 panel 1 | (0,445,375×667) | Yurneth Syd front view: white hood, face shadowed by design, gold-and-gem necklace; Sirris's pauldron at the right edge | Literal panel; bubbles above and below excluded. |
| 20 | s-005 panel 3 | (60,3340,450×800) | Han close-up, calm and knowing ("they weren't AIs") | Literal panel; thought-bubble tail dots above the window excluded. |
| 21 | s-007 panel 1 | (90,260,450×800) | Jenna's amazed close-up — "Wow… what happened?!" | Literal panel for the beat; its bubble sits above the crop. |
| 23 | s-007 group panel | (0,1780,320×569) | Jenna looking up in wonder inside the gleaming Lobby Lv.2, Aaron's shoulder at the lower-right edge | **SUBSTITUTION.** Ch.7 has no restaurant-table panel — beats 23–24 play as Han's narration over the facilities tour. This is the nearest panel from the same sequence. |
| 24 | s-007 panel 6 | (150,8315,360×640) | Han's smug smirk (the gems line) | Literal panel; the narration boxes above/below excluded. |
| 25 | s-007 panel 7 | (240,9938,290×516) | Han's serious profile under the summoning announcement | **FLAG:** narrow source panel → 290 px wide crop, soft upscale. The "10 SUMMONINGS" banner above the panel is excluded. |
| 26 | s-008 explainer art | (360,80,360×640) | Gold summoning: white-silhouette hero cards, stacks and sacks of gold coins | Right half of the panel only — the "REGULAR SUMMONING USES GOLD" text bursts on the left are excluded. Card-corner ornaments are decorative patterns, not lettering. |
| 27 | s-007 walking panel | (20,11200,342×608) | Jenna's back in the foreground, Han walking ahead into the pink summoning light | **SUBSTITUTION.** Ch.7 has no clean pillars-of-light panel; this is the same summoning-hall moment, seconds earlier. |
| 28 | s-008 panel 5 | (400,6560,320×569) | Han turning with his sword in hand, addressing the newcomers | **SUBSTITUTION / FLAGGED — no usable literal panel.** The newcomers' crowd panel is saturated with murmur glyphs and bubbles on every possible 9:16 window, and the Dolf close-up has SFX glyphs baked over his face. Nearest usable same-scene panel used. |
| 30 | s-009 panel 1 | (65,452,289×513) | Iselle from behind (braids, wings, black dress) hovering over the newcomers; the black-haired newcomer's worried face front-left | Literal finale panel. The panel is short, so the crop is panel-bound (289 px source, soft upscale); its speech bubbles sit above/below the panel and are excluded. |
