# ff_s2ep5 — frame pack INDEX (S2E5 «Ten Minutes», manhwa ch.10)

All frames: bubble-free 800x1422 JPEG crops from the original ch.10 strips
(`~/workspace/pmu-anime/img/ch10/`), crop/panel-choice only — no painting,
no inpainting. Coordinates are (x, y, w×h) in original strip pixels.
Every file was visually verified: no speech bubbles, no text boxes, no
lettering, no SFX glyphs, no watermarks.

| Beat | Source | What the frame shows | Notes |
|---|---|---|---|
| 01 | s-005 (320,5595, 281×500) | Han mid-slash against a goblin brute, sword arc flashing | Tight action crop between the panel's two red SFX glyphs; soft upscale (~×2.85) — flagged |
| 03 | s-002 (15,4835, 330×587) | Gide shouting, leaning forward in his apron armour | From the rotation panel («HANSEN!»); plain gutter band at top, no text |
| 04 | s-002 (15,11030, 330×587) | Aaron shouting, spear shaft beside him | — |
| 05 | s-002 (400,7790, 320×569) | Jenna drawing her bow, braid flying, determined | Actual ch.10 panel (not the refs jenna_5) |
| 06 | s-001 (200,1330, 320×569) | Sunset vista over the ruined town, birds scattering | SUBSTITUTION: beat 6 is Han's mental calculation; ch.10 covers it with narration boxes over his fight — no bubble-free Han panel exists, so the chapter's own establishing vista anchors the clip opening |
| 08 | s-005 (330,3650, 390×693) | Han shouting mid-melee, dark cloak, dirtied face | Nearest clean Han melee panel; his sword arc is in motion (beat text is shield work — flagged) |
| 09 | s-003 (60,5420, 380×676) | Gide screaming, bloodied, red backdrop | The «ACKK» moment, cropped below the SFX lettering |
| 11 | s-003 (0,1790, 280×498) | Goblin head in profile, red eye, fangs bared | The horde panel in s-002 was too motion-blurred; this is the chapter's sharp goblin close-up |
| 12 | s-003 (210,10060, 300×533) | Gide frozen, tears streaming, eyes squeezed shut | The «MY HAND…!» fear panel, cropped inside the bubble/glyphs |
| 13 | s-004 (180,12040, 420×747) | Hansen shouting full-face | From the «MY SWORD IS BLUNT!» panel, above the bubble |
| 14 | s-003 (380,7330, 340×604) | Han shouting in profile, shield rim visible | — |
| 15 | s-001 (240,10170, 360×640) | Gide in profile, drained, sweat drop | From the kneeling-sword panel, cropped off its SFX glyph and bubble |
| 16 | s-006 (340,310, 300×533) | Gide's face, shocked and straining, breath clouds | From the «HANSEN, SWITCH…» panel |
| 17 | s-005 (0,11830, 300×533) | Jenna close-up, alarmed, Aaron's shoulder behind | SUBSTITUTION: Dika has no clean ch.10 panel; this is the manhwa's own Aaron↔Jenna rotation panel — same relief-rotation beat |
| 18 | s-006 (120,4060, 340×604) | Han shouting, grim, dirtied | From the «use all the arrows» panel, cropped between its two bubbles |
| 19 | s-001 (0,5680, 300×533) | Han's shouting half-face over his shield's edge | He is shouting the switch order in the manhwa; fits the «HOLD!» roar |
| 20 | s-004 (280,3480, 330×587) | Hansen's bruised, dirt-smeared face, apologetic | Cropped above the «S-SORRY» bubble and clear of the ASURA.GG watermark |
| 22 | s-005 (375,6795, 330×587) | Aaron shouting, bloodied cheek | SUBSTITUTION: no bubble-free wide «wall of bodies» panel exists in ch.10; Aaron speaks in this beat, so his reaction face from the same rotation sequence anchors the clip's landing frame |
| 23 | s-001 (430,10690, 240×427) | The fallen round shield on the ground, Gide's leg beside it | SUBSTITUTION: object panel from the kneeling scene — the shield already out of his hands; the literal fingers panel (s-003) is too short for a clean 9:16 crop |
| 25 | s-007 (25,185, 420×747) | Gide's face, wide terrified eyes, blood at the mouth | The brink-of-death close-up opening s-007 |
| 26 | s-005 (0,9880, 500×889) | Han screaming, extreme close-up | Cropped above his thought bubble |
| 27 | s-007 (350,2780, 370×658) | Jenna full body, frozen mid-step, braid swinging | The «WH-WHAT?!» panel |
| 28 | s-002 (400,5150, 320×569) | Hansen from above, gripping his shield handle, shouting, eyes shut | SUBSTITUTION: ch.10 has no Hansen-over-Gide wide panel (the chapter ends on Gide); this is Hansen planting himself with his shield — the same act, from the rotation sequence |
| 30 | s-007 (20,4620, 340×604) | Gide collapsed, face in the dirt, one eye half-open | The season-finale frame; cropped clear of the «GIDE!» bubble |
