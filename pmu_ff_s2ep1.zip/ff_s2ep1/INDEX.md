# Season 2 Episode 1 (ch.6 "Servant Number One") — Bubble-Free First-Frame Pack (ff_s2ep1)

All frames: **800×1422 px (9:16), JPEG q85**. Every frame was visually verified:
**no speech bubbles, no text boxes, no lettering, no SFX glyphs, no watermarks** anywhere in frame.
Method: cropping / panel choice only — nothing painted over, blurred, or inpainted.
Map: `prompts_s2ep1_merged.json` — 10 merged clips × 3 beats; frames exist for every beat that
starts or ends a merged clip (20 frames). Coordinates below are original strip pixels (strips are 720 px wide).

Grouping: 1:[1–3] lobby interrogation → account number · 2:[4–6] proof → fangirl → fan club ·
3:[7–9] 1-star → Niflheimr → troops · 4:[10–12] AIs? → living humans → million worlds ·
5:[13–15] entertainment → 100th stage → who brought me · 6:[16–18] authority → other lounges → pledge ·
7:[19–21] Jenna genius → principles → Aaron · 8:[22–24] servant #1 → fox-like → open storage ·
9:[25–27] storage → half-master → master-only · 10:[28–30] horrible rate → Extreme Hell → HUGE SUCCESS.

## Per-beat index

| Beat | File | Source | What the frame shows | Notes |
|---|---|---|---|---|
| 01 | ff_s2ep1_beat01.jpg | ch6 s-001, x450–720, y680–1160 | Iselle in profile, jabbing a pointing finger at Han (chapter's opening panel) | Clean window right of the panel's bubbles |
| 03 | ff_s2ep1_beat03.jpg | ch6 s-001, x460–690, y8371–8780 | Iselle laughing in disbelief, sweat drop — her reaction to the account number | **Substituted.** The beat's ending verification-screen panel is saturated with Korean SFX glyphs in every 9:16 window; this is the beat's own reaction panel. Top ~15% is blank strip margin above the panel border (no text) |
| 04 | ff_s2ep1_beat04.jpg | ch6 s-001, x265–563, y9800–10330 | Han smug close-up, eyes closed — "check it yourself" | The beat's literal dialogue panel |
| 06 | ff_s2ep1_beat06.jpg | ch6 s-002, x440–640, y4534–4890 | Chibi Iselle, eyes bulging in horror — "have I been cocky to the real Loki?!" | The beat's ending panel (manhwa's own chibi punctuation) |
| 07 | ff_s2ep1_beat07.jpg | ch6 s-002, x100–385, y2860–3367 | Han full body against the wall, signing the autograph tablet, wry annoyed face | **Nearest same-scene panel.** The beat's literal line panel is a hands/tablet close-up carrying SFX glyphs on the tablet itself |
| 09 | ff_s2ep1_beat09.jpg | ch6 s-003, x365–596, y2060–2471 | Chibi Iselle tearful, hands clasped — the "middle-level admin" confession | The beat's ending panel |
| 10 | ff_s2ep1_beat10.jpg | ch6 s-003, x0–310, y3370–3921 | Han's face reflected in the game-UI summoning screen (abstract UI shapes, no letters) | The beat's literal panel (prosecutor questions) |
| 12 | ff_s2ep1_beat12.jpg | ch6 s-004, x0–330, y2200–2787 | Han's profile and eye over the sea of world-bubbles — "1 million worlds" | The beat's literal vision panel; the dotted speech bubble sits outside the window |
| 13 | ff_s2ep1_beat13.jpg | ch6 s-003, x190–520, y5800–6387 | Chibi Han game-piece with sword and shield on the summoning grid, a giant player's hands above | The beat's literal panel (heroes as entertainment products) |
| 15 | ff_s2ep1_beat15.jpg | ch6 s-003, x384–620, y10000–10420 | Iselle apologetic, wings spread, hands at her chest — "...sorry" | The beat's ending panel ("I'll figure it out by climbing the tower" follows) |
| 16 | ff_s2ep1_beat16.jpg | ch6 s-003, x95–365, y11425–11905 | Han leaning on the lobby wall, arms crossed, looking down | The beat's literal panel (authority question) |
| 18 | ff_s2ep1_beat18.jpg | ch6 s-004, x190–520, y9340–9927 | Chibi Iselle sparkling with joy, hands clasped — the pledge | The beat's literal ending panel |
| 19 | ff_s2ep1_beat19.jpg | ch6 s-005, x60–390, y380–967 | Jenna mid dagger-slash, braid flying, amber eyes locked on target | The beat's literal panel |
| 21 | ff_s2ep1_beat21.jpg | ch6 s-005, x60–420, y2280–2920 | Aaron grimacing through a strained spear swing, impact burst | The beat's literal panel |
| 22 | ff_s2ep1_beat22.jpg | ch6 s-005, x0–330, y6500–7087 | Jenna in angry profile, shouting across at Iselle; Han's back at frame edge | The beat's literal panel (servant-#1 fight) |
| 24 | ff_s2ep1_beat24.jpg | ch6 s-005, x430–720, y9860–10376 | Han holding chibi Iselle out toward Jenna, deadpan — "don't worry, she's an idiot" | **Substituted.** The beat's ending wide storage shot is saturated: two Korean SFX glyphs, three bubbles and a watermark leave no clean 9:16 window. This is the beat's own opening panel, same scene |
| 25 | ff_s2ep1_beat25.jpg | ch6 s-006, x180–505, y340–918 | Storage interior: shelves, bins of materials, stacked ingots in dim light | The beat's literal establishing panel (no characters in this window) |
| 27 | ff_s2ep1_beat27.jpg | ch6 s-006, x365–660, y8044–8568 | Han in the forge, firelight on his shirt — "in a place like this?" | The beat's literal panel (Iselle teasing about Levatain/Brunac) |
| 28 | ff_s2ep1_beat28.jpg | ch6 s-006, x70–385, y6420–6980 | The lit forge furnace, flames and embers | **Substituted.** Every panel of this beat is a readable-text system box (penalty list / [SUCCESS RATE: HORRIBLE] UI) — unusable under the no-text rule. Nearest usable same-scene panel: the lit forge from the preceding beat |
| 30 | ff_s2ep1_beat30.jpg | ch6 s-008, x385–690, y610–1152 | Han smug in the blue pillar of success light, new longsword's glow at frame edge | The finale panel's clean window: the full panel also carries a "KYAAA!" burst, two teal SFX glyphs and the sword stat card — all excluded |

## Flags
- 4 frames are chibi-style (06, 09, 13, 18) — that is how the manhwa itself draws those beats (comedy/pledge punctuation); proportions match the source panels exactly.
- 4 substitutions (03, 07, 24, 28) — detailed above; in each case the beat's literal panel is unusable under the no-bubbles/no-text/no-SFX rule and the nearest usable panel from the same scene/beat was used. No panel was invented.
- Beat 03's frame carries a blank white margin strip at the top (strip spacing above the panel) — no text or art from another scene.
