# ff_ep3 — bubble-free first/last frames, Pick Me Up S1E3 (manhwa ch.4)

All frames: 800x1422 JPEG q85, cropped from chapter strips `img/ch4/` (crop/panel choice ONLY — no painting, blur or inpainting). NO speech bubbles, text boxes, lettering, SFX glyphs or watermarks in any file. Every file was viewed after production; several beats needed 2–4 re-crops to clear bubble edges/tails/fringes.

Merged clips (11): [1,2,3] [4,5] [6,7] [8,9,10] [11,12,13] [14,15,16] [17,18,19] [20,21] [22,23,24] [25,26,27] [28,29,30] — only clip-boundary beats need frames (22 files).

| Beat | File | Source strip + crop (x0,y0,x1,y1) | What it shows | Notes |
|---|---|---|---|---|
| 1 | ff_ep3_beat01.jpg | s-001 (395,420,800,1140) | Han battle close-up, Floor 2 fight already raging | First panel of the chapter; "IT'S NOT DEAD" bubble excluded by the right-side crop |
| 3 | ff_ep3_beat03.jpg | s-002 (105,11460,460,12091) | Han in profile + Jenna behind, glowing motes — stage-clear reaction | Breath-puff cloud and "...YES!" bubble cropped out (3rd attempt) |
| 4 | ff_ep3_beat04.jpg | s-003 (40,5060,400,5700) | Jenna alarmed full shot in the temple arena | Her "WHAT'S HAPPENING?!" bubble stays above the crop; Korean SFX fragment at bottom-right cropped out |
| 5 | ff_ep3_beat05.jpg | s-003 (370,11960,775,12680) | Iselle stretching/yawning in the emptied arena (log-off relief moment) | Motion squiggles are panel art, not text |
| 6 | ff_ep3_beat06.jpg | s-003 (455,13540,800,14153) | Han portrait before the carved stone door, "a floor a day" | Right portion of the panel — left part is blocked by his thought bubbles |
| 7 | ff_ep3_beat07.jpg | s-004 (0,610,365,1260) | Han's considering face under the dorm beams | Status window (pure text) ends above the crop; thought bubble forced the tight left crop |
| 8 | ff_ep3_beat08.jpg | s-004 (395,3180,800,3900) | Toby protesting, fist on chest; Jenna's hair foreground | Both protest bubbles excluded |
| 10 | ff_ep3_beat10.jpg | s-004 (82,9885,299,10300) | Shay's ghost — sepia flashback face close-up, turning her head | SUBSTITUTION: beat 10's Molmont panel is ringed by 3 bubbles with no clean window; the Shay panel is the same beat's second ghost (the script's beat 10 ends on Shay). Tight crop, source only 217 px wide → soft upscale; bubble fringe cleared on the 4th attempt |
| 11 | ff_ep3_beat11.jpg | s-004 (415,11910,800,12595) | Jenna earnest, hand on hip, night square | Starburst bubble spike and lower bubble cropped out |
| 13 | ff_ep3_beat13.jpg | s-005 (230,9195,635,9915) | Han standing over the fallen Yelson (shield rim + raised hand foreground), shouting down | Beat's end state; "WHILE WE WERE BLEEDING" bubble tail stays above the crop |
| 14 | ff_ep3_beat14.jpg | s-006 (150,300,600,1100) | Han mid-swing at the wooden training post, hall behind | Narration text box stays above the crop |
| 16 | ff_ep3_beat16.jpg | s-006 (430,11230,800,11888) | Jenna amazed, Han's fist pulling the arrow out in foreground | Matches the script's "rise to Jenna's amazement"; bubble + red SFX excluded |
| 17 | ff_ep3_beat17.jpg | s-007 (60,260,510,1060) | Han in combined sword-shield drill form, shield raised, glowing eyes | SUBSTITUTION: beat 17's own manhwa panel is a skill text box + an arm close-up covered in Korean SFX glyphs; frame = the immediately following drill panel ("KEEP GOING"), same training-hall scene |
| 19 | ff_ep3_beat19.jpg | s-007 (60,3290,369,3840) | Aftermath close-up: shield on the ground with arrows stuck in it, splintered wood | FLAG: the Lv.3 awakening itself is announced in text boxes only — no art panel exists; this is the panel immediately before the announcement, same scene |
| 20 | ff_ep3_beat20.jpg | s-007 (60,7060,499,7840) | Iselle screaming, pointing at the viewer | Black starburst bubble cropped out at the bottom |
| 21 | ff_ep3_beat21.jpg | s-008 (230,4700,680,5500) | The herded trio — Aaron centre, bruised and stung, eyes shut; Yelson left, Toby right | "Y-YES" bubble and command box excluded |
| 22 | ff_ep3_beat22.jpg | s-008 (0,10620,420,11367) | Han determined close-up with shield, Floor 3 field | His line's bubble + tail stay above the crop |
| 24 | ff_ep3_beat24.jpg | s-008 (60,12650,510,13450) | Han's finishing lunge, sword down into a goblin | FLAG: the Floor 3 clear / "MVP – JENNA" is a text box only; frame = the final-blow panel immediately before it |
| 25 | ff_ep3_beat25.jpg | s-009 (0,2700,307,3246) | Jenna in profile foreground, Yelson standing in the field behind | Panel geometry (two foreground heads + central bubbles) compresses the pair/trio staging into this crop |
| 27 | ff_ep3_beat27.jpg | s-009 (290,11880,740,12680) | Jenna beaming with her bow under the sunset — the rerun MVP moment | "STAGE CLEAR! MVP - JENNA" box and "HEHE." bubble cropped out |
| 28 | ff_ep3_beat28.jpg | s-010 (15,2540,251,2960) | Jenna with bow in the sunset field, montage clear | FLAG: montage panels are overlaid with mission/clear UI boxes; this is the largest clean window — source 236 px wide → soft upscale |
| 30 | ff_ep3_beat30.jpg | s-011 (180,2560,630,3360) | Han's horrified profile, one glowing blue eye — synthesis finale | The chapter's final face; UI warning boxes stay above the crop |

Beats NOT needing frames (mid-clip): 2, 9, 12, 15, 18, 23, 26, 29.
