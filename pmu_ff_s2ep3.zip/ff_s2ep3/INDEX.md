# Pick Me Up — S2 Episode 3 (manhwa ch.8, "Natural Selection") — first/last frame pack

22 boundary frames for 11 merged clips (grouping: 1:[1,2,3] 2:[4,5,6] 3:[7,8,9] 4:[10,11]
5:[12,13,14] 6:[15,16] 7:[17,18,19] 8:[20,21] 9:[22,23,24] 10:[25,26,27] 11:[28,29,30]).
Every frame is a crop/panel-choice ONLY from the original manhwa art — no painting, blur or
inpainting. Every frame was visually verified: NO speech bubbles, text boxes, lettering,
SFX glyphs or watermarks. Mid-clip beats (2, 5, 8, 13, 18, 23, 26, 29) need no frame per spec.
Crop boxes are (x0, y0, x1, y1) in the 720 px-wide source strip / refs file, resized to 800x1422.

Key story fact for this chapter: **the Party 2 dungeon battle is never drawn in ch.8** — John and
Teddy's deaths arrive only as system messages. Beats 3–4 are therefore anchored on the manhwa's
own goblin art from the refs pack, and several script tableaux that the chapter plays differently
(or as dialogue over other panels) use the nearest same-scene panel, flagged below.

## Frames

- **beat01** (clip 1 first) — ch8 `img/ch8/s-001.jpg`, Iselle splash panel, crop (160,1945,467,2491).
  Iselle shouting at full volume, arm raised, braids flying, over the gate hall. Direct panel for the
  Party 2 send-off (her "carpenters" shout in the chapter; same send-off splash). The panel's black
  speech boxes begin below the crop.
- **beat03** (clip 1 last) — `refs/goblin_1.png`, crop (26,150,414,840). **SUBSTITUTION:** ch.8 draws
  no Floor 3 battle at all. The manhwa's own Lv.3 goblin splash (ch.1) supplies the ambush: charging
  brute's face, glowing red eyes, tusks. The ref's "<GOBLIN LV.3>" lettering and speech bubble were
  cropped out (left window of the splash).
- **beat04** (clip 2 first) — `refs/goblin_1.png`, crop (500,273,800,806). **SUBSTITUTION:** same
  reason as beat 3 — the splash's second brute lunging in from the right, i.e. the second blade of
  "caught from two sides" for John's fall (the fall itself is not drawn in ch.8).
- **beat06** (clip 2 last) — ch8 `img/ch8/s-002.jpg`, survivors panel, crop (140,4030,430,4546).
  Chloe back in the lobby clutching her sword with both hands, tearful; Dika's sword arm at the left
  edge. Direct panel; her "I CAN'T" bubble sits right of the crop.
- **beat07** (clip 3 first) — ch8 `img/ch8/s-004.jpg`, crop (208,8635,567,9274). Chloe's tearful
  extreme close-up, tear rolling down (same panel as refs `chloe_1`). Direct manhwa close-up of her
  breaking down; the script's lobby-sobbing beat takes her canonical crying face from this chapter.
- **beat09** (clip 3 last) — ch8 `img/ch8/s-003.jpg`, crop (200,5650,500,6183). **NEAREST PANEL:**
  the script's training-ground lecture (Iselle explaining Aaron's fear-handling) is not drawn as
  such; the frame is Aaron in the same sequence right after stage clear — dirt-speckled, spear in
  hand, shaken (the "he killed ONE goblin" panel, its "ONE." bubble cropped out below).
- **beat10** (clip 4 first) — ch8 `img/ch8/s-002.jpg`, crop (230,5080,650,5827). Aaron bellowing
  "I'll fight with you!", spear in hand, plaza behind him. Direct panel — the manhwa's volunteering
  moment behind the script's flashback.
- **beat11** (clip 4 last) — `refs/aaron_1.png`, crop (0,40,228,445). **SUBSTITUTION:** ch.8 has no
  tear-wiping/grin panel for Aaron's "greedy, that's how I survived" line; his refs summoning
  portrait (nervous sweat, half-smile, vest and lace-up shirt) anchors him. The ref's Korean SFX
  glyphs sit right of the crop.
- **beat12** (clip 5 first) — ch8 `img/ch8/s-005.jpg`, crop (0,9410,350,10032). **NEAREST PANEL:**
  Enok's introduction close-up — sturdy build, stubble, red neckerchief, green vest (the manhwa's
  Enok design; it differs from the script's bible block, and the frame deliberately follows the
  manhwa). No hammer-catch panel exists and Iselle is not in frame; Han's silhouette enters at the
  bottom edge (over-shoulder). This crop is Enok's only clean panel, so it anchors him.
- **beat14** (clip 5 last) — ch8 `img/ch8/s-004.jpg`, crop (200,1425,560,2065). Dolf ranting
  red-faced behind the heaped potato bowl. Direct panel from his five-star-chef claim scene.
- **beat15** (clip 6 first) — ch8 `img/ch8/s-004.jpg`, crop (110,3695,402,4215). **NEAREST PANEL:**
  Dolf's sweating profile in extreme close-up — the fraud-reveal beat (the status window directly
  above this panel in the chapter shows he has NO cooking skill). The script's burnt-dish tableau
  is not a single panel; this is the literal moment the lie collapses.
- **beat16** (clip 6 last) — ch8 `img/ch8/s-005.jpg`, crop (200,4590,620,5337). Han tasting, eyes
  closed, potato piece below — an extreme close-up because the manhwa panel itself is one. Direct
  panel (bubbles above and below cropped out).
- **beat17** (clip 7 first) — ch8 `img/ch8/s-004.jpg`, crop (0,10330,340,10935). **SUBSTITUTION
  (flagged prominently):** the script's Earth flashback (Han dining alone in a modern restaurant)
  **does not exist in ch.8** — it is a script invention. Nearest same-scene panel used: Han alone
  in profile at the restaurant table, eyes closed over a bowl of potatoes, tasting nothing — the
  visual rhyme the chapter actually offers for that beat.
- **beat19** (clip 7 last) — ch8 `img/ch8/s-005.jpg`, crop (22,11095,258,11515). Dolf's terrified
  face — wide eyes, sweat, mouth open — from the synthesis-threat panel itself. Direct scene; the
  composition is the reaction side of the threat (Han's smirking half of the same panel is
  sandwiched between two speech bubbles and cannot be cropped bubble-free at 9:16).
- **beat20** (clip 8 first) — ch8 `img/ch8/s-006.jpg`, crop (28,5270,270,5700). **NEAREST PANEL:**
  Gide's portrait from the trainee-introduction panel (frog-button tunic, stern, sweat drop;
  Hansen's shoulder at the right edge). The script's three-man salute lineup cannot be cropped
  bubble-free at 9:16 — chibi sticker bubbles intrude under the trio — so Gide, the beat's speaker,
  anchors it.
- **beat21** (clip 8 last) — ch8 `img/ch8/s-006.jpg`, crop (60,7400,480,8147). **NEAREST PANEL:**
  Gide lunging at Han in sparring, eyes glowing, Han shouting at the left edge. In the manhwa the
  weapon/role assignment is played as this training-ground sparring sequence rather than a
  hand-out tableau.
- **beat22** (clip 9 first) — ch8 `img/ch8/s-007.jpg`, crop (402,2180,720,2745). **NEAREST PANEL:**
  Aaron addressing the plaza with Gide, Hansen and Dika behind him and the new summons' backs in
  the foreground. The manhwa shows the crowd right after the second ×10 pull (grey-toned); no
  light-pillar summoning panel exists in ch.8.
- **beat24** (clip 9 last) — ch8 `img/ch8/s-007.jpg`, crop (300,9450,625,10028). **NEAREST PANEL:**
  the chapter's own tower illustration — the cylindrical tower with red-lit windows under an ember
  sky. The script's "Iselle projects a tower of light" beat takes the manhwa's real tower art as
  the boss-floor visual; the panel's text boxes sit left/below the crop.
- **beat25** (clip 10 first) — ch8 `img/ch8/s-007.jpg`, crop (90,7580,472,8260). **NEAREST PANEL:**
  Han's grave extreme close-up (eye, gritted teeth) from the boss-stage explanation conversation.
  The script's finger-counting tableau with Iselle confirming is not drawn; this is Han mid-way
  through that exact exchange.
- **beat27** (clip 10 last) — ch8 `img/ch8/s-006.jpg`, crop (250,3650,610,4290). **NEAREST PANEL:**
  Han on the training ground gripping a wooden staff, hard instructor stare. No assembly-speech
  panel exists for the max-capacity declaration; Han-as-instructor anchors it.
- **beat28** (clip 11 first) — ch8 `img/ch8/s-006.jpg`, crop (330,9620,690,10260). Jenna mid-drill,
  quiver on her back, braid flying, shouting — the training montage's drill-leader panel. Direct.
- **beat30** (clip 11 last) — ch8 `img/ch8/s-006.jpg`, crop (128,2156,591,2979). **SUBSTITUTION:**
  ch.8's actual finale (s-008) is a text roster card — unusable under the no-lettering rule. The
  frame is the chapter's aerial night view of the whole lobby (summoning circle, training yard,
  restaurant): the assembled home the official roster defends, closing the episode.

## Notes

- Manhwa Enok (beat 12) wears a red neckerchief and green vest in ch.8; the script's bible block
  describes a leather apron/hammer. Frames follow the manhwa per the v3 method; the generation
  prompt text is unchanged from the script.
- Several frames are upscaled from narrow crops (beats 11, 19, 20 especially) — same precedent as
  Ep.1's pack; all are 800x1422 JPEG q85.
