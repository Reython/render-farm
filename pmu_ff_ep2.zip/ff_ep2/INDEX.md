# Pick Me Up — Episode 2 (manhwa ch.3) first-frame pack — INDEX

All frames: 800×1422 JPEG q85, cropped from the chapter-3 strips in `img/ch3/` (crop / panel choice only, never painted or inpainted). Every file was view-verified: NO speech bubbles, text boxes, lettering, SFX glyphs or watermarks anywhere in frame.

Grouping (10 merged clips × 3 beats): [1-3] [4-6] [7-9] [10-12] [13-15] [16-18] [19-21] [22-24] [25-27] [28-30]. Frames exist for the 20 boundary beats (first/last beat of each merged clip).

| Beat | File | Source | What the frame shows | Notes |
|---|---|---|---|---|
| 1 | ff_ep2_beat01.jpg | s-002, crop (0,600,420,1347) | Han lunging low in the dawn training yard, profile face gritted, speed lines, barrier glow | Substitution: ch.3's own opening splash (s-001) is blocked by baked-in SFX glyphs and its aerial panel has no readable face; this is the same dawn-training sequence's action panel |
| 3 | ff_ep2_beat03.jpg | s-001, crop (80,10230,510,10994) | Extreme close-up of Han's face, gritted grin, sweat — the "I have to become stronger" resolve panel | Tight crop threaded between the two spiky thought bubbles that frame the panel |
| 4 | ff_ep2_beat04.jpg | s-002, crop (430,7450,800,8108) | Jenna arriving in the yard, face to camera, red braid, beige tunic | The beat's own panel; Han is present only as a hair silhouette at the left edge |
| 6 | ff_ep2_beat06.jpg | s-003, crop (20,350,440,1097) | Over-shoulder Jenna at full bow draw, arrow nocked | The beat's own panel |
| 7 | ff_ep2_beat07.jpg | s-003, crop (0,5040,320,5609) | Han close-up, eyes closed, fist at chin — assessing Jenna during the interview | The beat's own two-shot panel, Han side |
| 9 | ff_ep2_beat09.jpg | s-003, crop (0,10740,420,11487) | Han's calm face, slight smile — the panel of his line "Alright. I'll help you." | Substitution within the beat: the literal extended-hand panel is only ~325 px tall (any 9:16 crop would include blank page); this face panel is the same beat's lead panel |
| 10 | ff_ep2_beat10.jpg | s-004, crop (120,1350,620,2239) | Two hands clasped with warm glow kindling between them — the intimacy-bonus moment | The beat's own panel |
| 12 | ff_ep2_beat12.jpg | s-004, crop (450,7090,770,7659) | Iselle diving furiously over the training scarecrows | Substitution: beat 12's own large Iselle panel is ringed by black speech bubbles around her face; this is her entrance-dive panel from the same exchange (same scene, seconds earlier) |
| 13 | ff_ep2_beat13.jpg | s-004, crop (310,11605,620,12156) | Iselle nervous, eyes shut, sweating, grin dying, arms crossed | The beat's own splash panel; the "<ISELLE LV.257>" lettering is cropped out above the frame |
| 15 | ff_ep2_beat15.jpg | s-005, crop (60,445,390,1032) | Han's knowing close-up — "Her reaction has made me certain" | The beat's own monologue panel |
| 16 | ff_ep2_beat16.jpg | s-005, crop (360,2072,555,2419) | Iselle hovering in her glow against the lobby brick wall, braids and dress full in frame | FLAG — tightest fairy frame: the beat's wide two-shot panel is bisected by her hex speech bubble and Han appears only from behind, so this is the largest clean window of that panel; her face is small and shadowed under her bangs in the original art |
| 18 | ff_ep2_beat18.jpg | s-005, crop (0,8760,275,9249) | Han smirking — "Thanks for the tip. Keep it up." | The beat's own panel |
| 19 | ff_ep2_beat19.jpg | s-005, crop (25,12855,310,13362) | Han in profile turning toward the arriving Jenna | The beat's own panel ("What are you guys talking about?") |
| 21 | ff_ep2_beat21.jpg | s-006, crop (45,10260,405,10900) | Dorm-room stone fireplace with a roaring fire | The beat's own room panel: the manhwa visualizes the refill/drawer rule with the room interior — no character panel exists for this beat |
| 22 | ff_ep2_beat22.jpg | s-007, crop (508,288,768,750) | Extreme tight profile fragment of Han — eye, nose contour, mouth — on teal | FLAG — tightest crop in the pack (260 px source width): the beat's narration panel is a giant profile head hemmed in by the narration box, thought dots and bubble on all sides; this is the largest clean window it yields |
| 24 | ff_ep2_beat24.jpg | s-007, crop (300,6620,660,7260) | Shirtless Han mid-stretch, gritted grin, sweat, speed lines — day-three training | The beat's own panel; two translucent blank breath puffs beside his face are part of the panel art (no text) |
| 25 | ff_ep2_beat25.jpg | s-007, crop (0,11700,330,12287) | Han in the plaza two-shot, fist raised, determined | The exchange panel carrying his lines "Two skills from training… Get ready. Master's here." |
| 27 | ff_ep2_beat27.jpg | s-008, crop (325,3345,550,3745) | Aaron portrait — spiky blond hair, vest, worried sweat drop — on the plaza steps | From the newcomers panel; supersedes refs/aaron_1.png for frame use (that wider crop contains bubbles/glyphs) |
| 28 | ff_ep2_beat28.jpg | s-008, crop (345,5710,626,6210) | Jenna in a fighting stance shouting orders in the square, braid swinging | Substitution: script beat 28 (Iselle binding the newcomers) is visualized in the manhwa only by text banner panels; this is Jenna rallying the newcomers in the same summoning sequence — nearest usable same-scene panel |
| 30 | ff_ep2_beat30.jpg | s-010, crop (0,3020,355,3660) | Prairie wolf head close-up — glowing amber eyes, scarred brow, fangs | The beat's own monster-reveal panel; the red name-tag lettering and SFX glyphs are cropped out |
