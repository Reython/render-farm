# ff_ep4 — first/last frame pack, Season 1 Episode 4 (manhwa ch.5, "I Am Loki")

All frames 800x1422 JPEG, cropped from chapter-5 strips (`img/ch5/`) by crop/panel
choice ONLY (no painting/blurring/inpainting). Every file viewed and verified:
NO speech bubbles, text boxes, lettering, SFX glyphs or watermarks in any frame.

Merged clips (11): [1,2,3] [4,5,6] [7,8,9] [10,11,12] [13,14] [15,16,17]
[18,19,20] [21,22,23] [24,25,26] [27,28] [29,30] — 22 boundary beats framed.

## Frames

- **beat01** (clip 1 first) — s-001 p02 (strip y3829–5334), crop x140 y4250 w400.
  Han close-up, calm half-face in the lobby — the favorited pair's quiet opening.
  Direct panel, no substitution.
- **beat03** (clip 1 last) — s-001 p06 (y10213–11780), crop x460 y10950 w330.
  Han close-up delivering the verdict line ("judged for what you've done") over
  Yelson's shoulder — lands the reassurance scene. Direct panel (shared with
  beat 4's opening question; cropped to Han's side).
- **beat04** (clip 2 first) — s-001 p07 (y11969–13844), crop x490 y12889 w300.
  Han's dry smirk with chibi Iselle ranting at frame bottom — the panel of her
  "first time I like the words coming out of your mouth" payoff. Direct panel.
- **beat06** (clip 2 last) — s-002 p04 (y6235–8015), crop x460 y6700 w330.
  Yelson's screaming face dissolving into blue synthesis light. Direct panel.
- **beat07** (clip 3 first) — s-002 p05 (y9221–10965), crop x320 y9880 w350.
  Jenna stunned, hand in her hair, golden eyes lit — Eagle's Eye just gained.
  Direct panel.
- **beat09** (clip 3 last) — s-003 p00 (y0–1625), crop x320 y360 w420.
  Iselle shouting the next summon call over the square. Direct panel. (Toby's
  joy panel from this beat is used for beat 10's frame instead — see below.)
- **beat10** (clip 4 first) — s-003 p04 (y4967–7117), crop x160 y5450 w287.
  Toby's ecstatic laughing face at the chamber doors — he believes he is going
  home. Direct panel; window tightened 4 rounds to exclude his starburst
  speech bubble entirely.
- **beat12** (clip 4 last) — s-003 p09 (y13303–14687), crop x500 y13783 w290.
  Han's eye-and-grin close-up ("Why do you look so gloomy?") — the beat's
  closing exchange with Jenna. Direct panel.
- **beat13** (clip 5 first) — s-003 p08 (y11078–12716), crop x40 y11478 w360.
  Aaron's frightened profile, sweating — the "You got lucky" panel; his fear of
  being the next sacrifice. Direct panel.
- **beat14** (clip 5 last) — s-004 p02 (y4192–5219), crop x400 y4550 w370.
  Han extreme close-up (eye, gritted mouth) giving the "correct side" advice.
  Direct panel.
- **beat15** (clip 6 first) — s-005 p02 (y1865–2933), crop x180 y1900 w560.
  Han with wooden sword on his shoulder and smiling Jenna at the armory racks;
  Aaron's fist at the frame edge (his point of arrival). Direct panel.
- **beat17** (clip 6 last) — s-005 p04 (y5860–7468), crop x0 y6180 w320.
  Han gripping the wooden sword, glaring ("How can I trust you?").
  SUBSTITUTION: Aaron's kneeling figure in this same panel is boxed in by three
  speech bubbles and an SFX glyph on every side — no bubble-free window exists
  around him. The beat's other half (Han, whose softening glare resolves the
  beat) from the same panel is used.
- **beat18** (clip 7 first) — s-005 p07 (y10985–13388), crop x90 y11605 w480.
  Aaron holding the spear, spearhead prominent at frame left, stunned —
  "That's a spear." Direct panel.
- **beat20** (clip 7 last) — s-006 p02 (y2827–6187), crop x482 y2945 w228.
  Aaron's panicked shouting face, tight crop. FLAG: s-006's sparring panels are
  saturated with Korean SFX glyphs; this is the only glyph-free face window in
  the sequence. The flat-on-his-back landing has no bubble/SFX-free panel;
  Aaron's overwhelmed panic face from the same panel is used.
- **beat21** (clip 8 first) — s-007 p01 (y1967–3443), crop x0 y2097 w360.
  Han's angry close-up. SUBSTITUTION: the knockdown panels (s-006 p03/p04,
  s-007 p00) carry SFX glyphs and bubbles over every face; Han's close-up from
  the same sequence's panel (which carries Jenna's "too harsh?" protest and
  Han's answer) is used.
- **beat23** (clip 8 last) — s-007 p04 (y6399–8282), crop x0 y6639 w340.
  Han at dusk looking back over his shoulder, embers in the air — matches the
  script's stated closing image ("the hero's silhouette, alone inside his own
  answer"). SUBSTITUTION: the little-sister panel (s-007 p02) boxes Aaron in
  with three speech bubbles; this same-conversation panel (the beat's closing
  line, "What would happen if you don't go back?") is used.
- **beat24** (clip 9 first) — s-007 p05 (y8709–10234), crop x450 y9230 w320.
  Aaron's gritted teeth and sweat in extreme close-up, the wooden sword's blade
  resting at his throat — the last warning. Direct panel.
- **beat26** (clip 9 last) — s-008 p02 (y4122–5763), crop x0 y4620 w390.
  Han's calm smirk, waiting the rant out. SUBSTITUTION: Iselle's figure in this
  same panel is boxed in by a black text box and a pink SFX glyph; Han's half
  of the panel is used (the beat ends on Han, done with games).
- **beat27** (clip 10 first) — s-008 p04 (y8152–9816), crop x430 y8607 w350.
  Iselle laughing with crossed arms, preening — "Web surfing is my hobby"; she
  drifts straight into the trap. Direct panel.
- **beat28** (clip 10 last) — s-008 p05 (y10128–11756), crop x110 y10708 w330.
  Han, arms crossed, reciting the forum post word for word. SUBSTITUTION:
  Iselle's reaction figure in this panel is a backlit silhouette boxed in by
  two black text boxes; Han's figure from the same panel is used.
- **beat29** (clip 11 first) — s-008 p06 (y12199–14296), crop x540 y13350 w260.
  Chibi Iselle blushing, eyes sparkling, under Loki's dragon emblem — the
  fangirl revealed. Direct panel.
- **beat30** (clip 11 last) — s-009 p04 (y5288–6946), crop x205 y5705 w390.
  Han extreme close-up, glowing blue eyes, slow grin — "I am Loki." The
  manhwa's own season-finale panel. Direct panel.

## Notes
- 12 of 22 frames needed re-crops (bubble/SFX edges found on first pass);
  beats 10 and 20 needed 3–4 rounds. Final set: all 22 verified clean by view.
- Beats 2, 5, 8, 11, 16, 19, 22, 25 are mid-clip and need no frame, per spec.
