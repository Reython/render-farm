# S2 Episode 4 (manhwa ch.9 "1,846") — first-frame pack INDEX

All frames: crop/panel-choice ONLY from ch.9 strips (`img/ch9/`), resized to 800x1422 JPEG.
Every file was viewed and verified free of speech bubbles, text boxes, lettering, SFX glyphs
and watermarks. Only clip-boundary beats have frames (22 of 30 beats).

## Clip → frames

| Clip | Beats | First frame | Last frame |
|------|-------|-------------|------------|
| 1 | 1–2 | beat01 | beat02 |
| 2 | 3–5 | beat03 | beat05 |
| 3 | 6–8 | beat06 | beat08 |
| 4 | 9–11 | beat09 | beat11 |
| 5 | 12–14 | beat12 | beat14 |
| 6 | 15–17 | beat15 | beat17 |
| 7 | 18–20 | beat18 | beat20 |
| 8 | 21–22 | beat21 | beat22 |
| 9 | 23–25 | beat23 | beat25 |
| 10 | 26–28 | beat26 | beat28 |
| 11 | 29–30 | beat29 | beat30 |

## Per-frame notes

- **beat01** — ch9 s-001, formation-fight panel. Gide mid-fight (sword + raised shield) with
  Hansen's grimacing face at the edge: the Floor 4 drill. The panel's own SFX and the
  "THAT'S THE FORMATION!" bubble sit outside the crop window.
- **beat02** — ch9 s-002, Jenna close-up (S2 outfit, loose red hair, gentle smile) with Han's
  shoulder beside her — the "THEY DID GOOD" panel, cropped between its two bubbles.
- **beat03** — ch9 s-002, lobby plaza panel: Dika (foreground left) and Gide (right) smiling,
  Jenna/Han/Aaron behind them. Cropped right of the "HOW WAS IT?" bubble. *Flag: Han is a
  background figure here, not foreground — no bubble-free crop of this panel centers him.*
- **beat05** — ch9 s-003 opening splash: Han in full gear (dark jacket, shield on back), Aaron
  at the edge. *Substitution (same arc): the chapter's gear-distribution visual is this splash
  of the geared party; the trainees' own equipping line is not drawn bubble-free. Text-free.*
- **beat06** — ch9 s-003, synthesis-cards panel: Dolf's card (name banner renders blank/black,
  star icon only — no letters) over the lobby building. Cropped between the narration boxes.
- **beat08** — ch9 s-004, gate-arrival panel: the party materializing in the ring of light on
  the Floor 5 street (Jenna, Han, Aaron + one more visible). *Flag: the chapter's own arrival
  panel shows only part of the eight; the Korean SFX glyphs around it are outside the crop.*
- **beat09** — ch9 s-004, clock-tower establishing panel over the deserted city. Fully clean.
- **beat11** — ch9 s-004, street panel: Aaron's tense close-up advancing through the empty
  street (Hansen's shield edge at frame left). Cropped below the "HYUNG-NIM..." bubble.
  *Flag: beat dialogue belongs to Gide/Hansen, but the only bubble-free crop of this panel is
  Aaron — he leads the same advance.*
- **beat12** — ch9 s-005, the clock tower Han points the scout to (Han's hair sliver at the
  frame edge; bubble tail cropped out above).
- **beat14** — ch9 s-005, Aaron shouting up at the tower — the count being called down.
  *Framing note: the literal "HOW MANY?!" Han panel could not be cropped bubble-free (two
  burst bubbles overlap every 9:16 window); this is the same exchange from the panel above it
  in the chapter.*
- **beat15** — ch9 s-006, Han's face as he works out the mission ("not subjugation — survival").
  Cropped clear of both flanking bubbles.
- **beat17** — ch9 s-006, trainee grimacing against a sealed house door, shield in hand.
  *Flag: tight, small-source crop (≈190 px wide, upscaled — softer than the rest). Both
  literal sealed-door panels carry either the red "YOU CAN NOT ENTER" sign or bubbles in
  every 9:16 window; this face crop is the only text-free window of the actual panel.*
- **beat18** — ch9 s-006, extreme close-up of Han's eyes deciding (warm grade of the original
  panel). *Substitution (same arc): the literal intersection-survey panel (Gide shouting
  beside Han) is bubble-saturated in every window; this is Han's deciding beat two panels on.*
- **beat20** — ch9 s-007, Jenna with her bow amid the rubble and scattered beams of the defense
  intersection. *Substitution (same arc): the literal barricade-hauling panels (Gide/Han with
  beams) are saturated with SFX glyphs and burst bubbles in every 9:16 window; this is the
  same intersection-defense sequence, moments later. The positions panel above it carries a
  full narration bubble and was rejected for that reason.*
- **beat21** — ch9 s-008, Han grimacing, sweat, gripping the barricade plank — the "too late"
  moment. Cropped between the timer-thought bubbles.
- **beat22** — ch9 s-006 opening splash: the goblin horde in darkness, red eyes — cropped in
  the one window between the splash's three purple SFX glyphs.
- **beat23** — ch9 s-008, giant goblin face close-up filling the frame — the enemy arriving at
  the street mouth. *Monster-side framing of beat 23's moment (Han/Aaron bracing): their own
  panels here carry burst bubbles; this is the first goblin they face, same panel sequence.*
- **beat25** — ch9 s-001, Gide roaring behind his raised shield at the drill.
  *Substitution: in ch.9 the timer itself is a digital text window (29:59) — unusable under
  the no-text rule — so the "trainees lock in as the timer starts" beat uses the chapter-arc's
  own shield-lock visual of the same trainee.*
- **beat26** — ch9 s-008, Han roaring the "wall of corpses" order, Aaron at his shoulder.
  Cropped between the order bubble above and the "RIGHT!" bubble below. Literal panel.
- **beat28** — ch9 s-009, Jenna shouting in profile mid-battle at the center.
  *Flag: Dika is not in frame — the chapter never draws Dika feeding arrows; Jenna's solo
  center-fire panel is the only bubble-free center visual.*
- **beat29** — ch9 s-009, Aaron roaring mid-battle, fear mastered ("We just need to survive
  ten minutes!"). Cropped between the shout bubbles and the SFX glyph below. Literal panel.
- **beat30** — ch9 s-010, the chapter's final image: the sea of goblin faces and glowing red
  eyes in darkness — the first wave looming. Fully clean, no text anywhere in the panel.
